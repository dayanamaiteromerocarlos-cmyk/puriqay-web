import { useState } from 'react';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { supabase } from '../lib/supabase';
import { traducirErrorAuth } from '../lib/authErrors';
import FondoParticulas from './FondoParticulas';

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });

    setLoading(false);

    if (error) {
      toast.error(traducirErrorAuth(error));
      return;
    }
    // Mensaje genérico a propósito: no revela si el correo está registrado.
    setSent(true);
  };

  return (
    <div className="min-h-screen relative isolate bg-white flex justify-center items-center p-4">
      <FondoParticulas />
      <div className="w-full max-w-md bg-white/30 backdrop-blur-[2px] p-8 md:p-10 rounded-3xl shadow-xl border border-white/70 border-t-[6px] border-t-pq-brand">

        <div className="text-center mb-10">
          <h1>
            <img src="/img/puriqay-plus-by-puriqay.png" alt="Puriqay +, by Puriqay Voluntariado" className="w-64 max-w-full h-auto mx-auto" />
          </h1>
          <p className="text-pq-teal-dark/70 font-bold uppercase tracking-widest text-xs mt-4">Recuperar contraseña</p>
        </div>

        {sent ? (
          <div className="space-y-6">
            <div className="bg-pq-cream/50 text-pq-teal-deep text-sm text-center font-bold p-4 rounded-xl border border-pq-cream-dark">
              Si el correo está registrado, te enviamos un enlace para restablecer tu contraseña. Revisa también tu carpeta de spam.
            </div>
            <p className="text-center text-sm text-pq-ink/70 font-medium">
              <Link to="/" className="text-pq-teal font-black hover:text-pq-teal-dark transition-colors hover:underline">Volver a iniciar sesión</Link>
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <p className="text-sm text-pq-ink/70 font-medium text-center">
              Ingresa tu correo y te enviaremos un enlace para crear una nueva contraseña.
            </p>

            <div>
              <label className="block text-sm font-bold text-pq-teal-dark mb-2">Correo Electrónico</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 border-[1.5px] border-pq-border rounded-xl bg-white focus:border-pq-teal focus:shadow-pq-focus outline-none transition-all font-medium text-pq-ink"
                placeholder="tu@correo.com"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-pq-teal hover:bg-pq-teal-dark text-white font-bold py-3.5 px-4 rounded-xl shadow-lg shadow-pq-teal/30 hover:-translate-y-0.5 transition-all duration-200 mt-2"
            >
              {loading ? 'Enviando...' : 'Enviar enlace'}
            </button>

            <p className="text-center text-sm text-pq-ink/70 mt-6 font-medium">
              <Link to="/" className="text-pq-teal font-black hover:text-pq-teal-dark transition-colors hover:underline">Volver a iniciar sesión</Link>
            </p>
          </form>
        )}
      </div>
    </div>
  );
}
